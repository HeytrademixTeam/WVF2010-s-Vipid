Before you run this program, you must download Vegas Pro 13 and up.
Also, if you need to render the edited templates, you must click the render button. DO NOT OVERWRITE THE TEMPLATE!